% graphs

j = 1;
for i=100000:10000:1000000
    bps(j) =ntd('MC',5,0.1,ones(1,5)*0.01,0.05,0.4,1,1,i);
    j = j+1
end